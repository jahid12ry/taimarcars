 <style type="text/css">
    .logo{
        float: left;
        filter: invert(1);
        object-fit:  contain;
        mix-blend-mode: ;
    }

</style>
 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TaiMar Cars</title>
    <link rel="stylesheet" href="<?php echo base_url().'assets/css/bootstrap.min.css';?>">
    <script src="<?php echo base_url().'assets/js/jquery-3.6.0.min.js';?>"></script>
    <script src="<?php echo base_url().'assets/js/bootstrap.min.js';?>"></script>
    <script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
    <link rel="stylesheet" href="<?php echo base_url('/assets/css/style.css'); ?>">
    <link rel="shortcut icon" href="<?php echo base_url('assets/hii.png') ?>">
    <style>
    
</style>
</head>

<body>

    <!-- Navigation -->
 
    <nav class="navbar navbar-expand-md navbar-light sticky-top" style="background-color:black;  ">
        <div class="container-fluid">
          <a class="logo" href="<?php echo base_url().'';?>">
                <img src="assets/li.png"  class="rounded-circle ">
           </a>

            <a class="text-white"  style="margin-left:100px;" href="tel:01865 749162">01865 749162</a>
            
           <li>
            <a class="text-white" style="margin-left:170px" href="mailto:info@taimarcars.com">  info@taimarcars.com</a>
               
           </li>
  
            <button class="navbar-toggler text-center" type="button" data-toggle="collapse" data-target="#navbarRes" style="background-color:white;">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse text-center" id="navbarRes" style="margin-left:200px">

                      
                <ul class="navbar-nav ml-auto text-center">
                     
                    <li class="btn-group" role="group" aria-label="Basic outlined example">
                        <a class="btn btn-outline-light" href="<?php echo base_url().'';?>">Home</a>
                    </li>
                    <li class="btn-group" role="group" aria-label="Basic outlined example">
                        <a class="btn btn-outline-light" href="<?php echo base_url().'about';?>">About</a>
                    </li>
                    <li class="btn-group" role="group" aria-label="Basic outlined example">
                        <a class="btn btn-outline-light" href="<?php echo base_url().'restaurant';?>">Services</a>
                    </li>
                    
                     
                     
                    <li class="btn-group" role="group" aria-label="Basic outlined example">
                        <a class="btn btn-outline-light" href="<?php echo base_url().'cart';?>">Airport Prices</a>
                    </li>
                    <li class="btn-group" role="group" aria-label="Basic outlined example">
                        <a class="btn btn-outline-light" href="<?php echo base_url().'contact';?>">Get Quatation</a>
                    </li>


              <li class="btn-group" role="group" aria-label="Basic outlined example">
                        <a class="btn btn-outline-light" href="<?php echo base_url().'login';?>">Contact</a>
                    </li>
                  
<!-- Navigation <li class="btn-group" role="group" aria-label="Basic outlined example">
                        <a class="btn btn-outline-light" href="<?php echo base_url().'singup';?>">lol</a>
                    </li> -->
              


                </ul>
            </div>
        </div>
    </nav>
  
    
    
    <script>
    $(document).ready(function() {
        $(".dropdown").hover(function() {
            var dropdownMenu = $(this).children(".dropdown-menu");
            if (dropdownMenu.is(":visible")) {
                dropdownMenu.parent().toggleClass("open");
            }
        })
    });
    </script>