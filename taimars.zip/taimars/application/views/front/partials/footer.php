 
 <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>
<body>

 
  <footer class="footer position-sticky">
 
           <div class="container" style="justify-content: center; text-align: center;">
            <div class="row" style="justify-content: center; text-align: center;">
               <div class="footer-col" style="justify-content: center; text-align: center;">
                
                <ul style="justify-content: center; text-align: center;">
                    <li><a href="<?php echo base_url().'';?>"><h5>Home</h5></a></li>
                    <li><a href="<?php echo base_url().'about';?>"><h5>about us</h5></a></li>
                    <li><a href="<?php echo base_url().'restaurant';?>"><h5>our services</h5></a></li>
                    <li><a href="<?php echo base_url().'cart';?>"><h5>Airport Prices</h5></a></li>
                    <li><a href="<?php echo base_url().'contact';?>"><h5>Get Quotation</h5></a></li>
                    <li><a href="<?php echo base_url().'login';?>"><h5>Contact</h5></a></li>

                     
                </ul>
               </div>
           
               
           </div>
         </div>

    
    
     
  </footer>
  <div class="footerBottom">
    <h4>We accept payment using all major credit & debit cards</h4>
     

    <a class="icon">
                <img src="assets/h/visa.png"  class="rounded-circle ">
                <img src="assets/h/american-express.png"   >
                <img src="assets/h/apple-pay.png">
                <img src="assets/h/maestro.png">
                <img src="assets/h/mas.png">
                <img src="assets/h/ve.png">
           </a>
           <br>
        
        <p>Copyright &copy;2023; Powered by <span>TaiMar cars</span> </p>
        
    </div>

</body>
</html>

<style type="text/css">
    
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
body{
    line-height: 1.5;
    font-family: 'Poppins', sans-serif;
}
*{
    margin:0;
    padding:0;
    box-sizing: border-box;
}
.icon{
    height: 7vh;
    display: flex;
    justify-content: center;


}
.container{
    max-width: 1170px;
    margin:auto;
}
.row{
    display: flex;
    flex-wrap: wrap;
   
}
ul{
    list-style: none;
}
.footer{
    background-color:white;
    padding: 5px 0;
}
.footer-col{
   width: 25%;
   padding: 0 10px;
}
 
 
.footer-col ul li:not(:last-child){
    margin-bottom: 10px;
}
.footer-col ul li a{
    font-size: 16px;
    text-transform: capitalize;
    color:black;
    text-decoration: none;
    font-weight: 300;
    color: black;
    display: block;
    transition: all 0.3s ease;
}
.footer-col ul li a:hover{
    color: red;
    padding-left: 8px;
}
.footerBottom{
    background-color: white;
    padding: 20px;
    text-align: center;
} 
.footerBottom p{
    color: black;
}
 
/*responsive*/
@media(max-width: 767px){
  .footer-col{
    width: 50%;
    margin-bottom: 30px;
}
}
@media(max-width: 574px){
  .footer-col{
    width: 100%;
}
}







</style>