  <html lang="en">
  <head>
   <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

  </head>
  <body style="background-color:black;  ">
    
    <div class="service py-5" >
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-10 col-11 mx-auto">
            <div class="row">
              <!-- left side data -->
              <div class="col-md-6 mt-md-4 m-0 ">
                <span class="badge-light badge rounded-pill px-1 py-2 my-2  ">
                 <h2 class="text-black">About</h2>
                </span>
                <h4></h4>
                <h4 class="text-white ">TaiMar cars is a family run taxi service based in Oxford. 
We provide luxury and affordable vehicles according  to
your needs. We have experienced, professional and  
friendly taxi drivers who will take you to your destination  
with care and safety.
<br>
<br>
Our customers are always our main priority and we love
to offer our customer best professional services. We pride
ourselves on providing a reliable, punctual and
confidential taxi service to our clients. 
<br>
<br> 
Our service includes airport transfers, cruise   transfers, corporate
travel, business journeys, film sets,   special days out such
as Bicester Village, Soho farmhouse,  Silverstone Circuit, trips
to Oxford University, London or  other City  other
special occasions. Our vehicles have  FREE WIFI upon
request for our clients to enjoy during their journey.</h4>
                
              </div>


              <!-- right side data -->
               
              <div class="col-md-5 mt-md-5 m-0 img-container">
                <div class="row wrap-service uneven-box">
                  <!-- left side images -->
                          <div class="col-md-6">
                         <div class="row">
                         <div class="col-md-12 img-hover mb-4">
                        <img alt="ux" class="rounded img-shadow img-fluid" src="assets/h/s4.jpg" />
                        </div>
                       
                        </div>
                       </div>
                  <!-- right side images -->
                       <div class="col-md-6 uneven-box">
                       <div class="row">
                       <div class="col-md-12 img-hover mb-4">
                        <img alt="ux" class="rounded img-shadow img-fluid" src="assets/h/hiii.jpeg" />
                       </div>
                       
                       </div>
                       </div>
                    </div>
                  </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Optional JavaScript -->
    <!-- Popper.js first, then Bootstrap JS -->
    <script crossorigin="anonymous" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script crossorigin="anonymous" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js"></script>
  </body>

</html>  

<style type="text/css">
     @import url('https://fonts.googleapis.com/css2?family=PT+Sans&amp;display=swap');
    
  

.service_heading {
    text-transform: uppercase;
    position: relative;
}

.service_heading:after {
    content: '';
    position: absolute;
    top: 100%;
    left: 50%;
    transform: translateX(-50%);
    width: 0%;
    height: auto;
    border-bottom: 3px solid #3e4555;
    transition: all 0.3s linear;
}

.service_heading:hover:after {
    width: 20%
}

.service {
    color: #8d97ad;
    font-weight: 300;
}

.service h1, .service h2, .service h3, .service h4, .service h5, .service h6 {
    color: black;
}

.service h6 {
    line-height: 22px;
    font-size: 18px;
    color: #8d97ad;
}

.service .font-weight-medium {
    font-weight: 500;
    color: #3e4555;
}

.service .badge {
    line-height: 15px;
}

.service .badge-info {
    background: #188ef4;
}

.service .subtitle {
    color: #8d97ad;
    line-height: 24px;
}


.service .img-shadow {
    box-shadow: 0 0 30px rgba(115, 128, 157, 0.3);
     
}

.service .wrap-service .img-hover {
    transition: all 0.2s ease-in;
}

.service .wrap-service .img-hover:hover {
    -webkit-transform: scale(1.1);
    -ms-transform: scale(1.1);
    transform: scale(1.1);
}

.service .wrap-service .uneven-box {
    margin-top: 100px;
}

.service .btn-sm {
    padding: 6px 14px;
    font-size: 16px;
    background: #188ef4;
}

.service .btn-sm:hover {
    color: #188ef4;
    background: #fff;
    border: 1px solid #188ef4;
}

 
</style>