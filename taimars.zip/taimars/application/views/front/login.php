<!DOCTYPE html>
<html lang="en">
<!--divinectorweb.com-->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
</head>
<body>
    <div class="wrapper">
        <div class="btn-area">
            <div class="box bg-dark">
                <div class="boxes bx2">
                 <h2 class="text-white">Get in touch</h2>
                

                <a href="tel:01865 749162"><i class="fa fa-phone"></i></a>
                    <p class="mt-4 ms-3 text-white">Phone : 01865 749162</p>

                    <a href="mailto:info.taimarcars.com"><i class="fas fa-envelope"></i></a>
                    <p class="mt-4 ms-3 text-white">Email : info@taimarcars.com</p>
                    <li class="btn-group" role="group" aria-label="Basic outlined example">
                        <a class="btn btn-outline-info text-white" href="<?php echo base_url().'contact';?>">For A Quatation</a>
                    </li>
                
                
            </div>
                
            </div>
             
            
        </div>
    </div>
    
    
    
</body>
</html>
<style type="text/css">
    *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: poppins;
            text-decoration: none;
            list-style: none
        }
        .wrapper{
            display: -webkit-flex;
            display: -moz-flex;
            display: -ms-flex;
            display: -o-flex;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-image: url("assets/vs.jpg");
            -webkit-background-size: cover;
            background-size: cover;
            background-repeat: no-repeat;

            
        }
       
        #chkBox{
            display: none;
        }
        .mainContnt{
            width: 100%;
            height: 100%;
            display: -webkit-flex;
            display: -moz-flex;
            display: -ms-flex;
            display: -o-flex;
            display: flex;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.7s;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 300;
            background: yellow;
            
        }
        .box{
             
             
            width: 100%;
            height: 400px;
            
            transition: all 2s;
            margin: auto;
            
        }
        .bx1{
            background-image: url("assets/h/pon.jpeg");
            -webkit-background-size: cover;
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
        }
        .bx2{
            padding: 60px 32px 0 32px;
        }
        .bx2 h3 {
    margin-bottom: 16px;
    text-transform: uppercase;
}
        .login-form input {
    width: 100%;
    height: 52px;
    padding: 15px;
    margin-bottom: 25px;
}
        .login-form input[type="submit"] {
    background: yellow;
    font-size: 25px;
    text-transform: uppercase;
    line-height: 20px;
    color: blue;
}
        
        .close-box{
            position: relative;
            text-align: right;
            color: blue;
            font-weight: bold;
            margin-top: 64px;
            margin-bottom: 32px;
            
            
        }
        .box-close {
    position: absolute;
    bottom: 350px;
    right: 5px;
}
        #chkBox:checked + .mainContnt{
            visibility: visible;
            opacity: 1;
        }
        #chkBox:checked + .mainContnt .box{
            transform: translateY(0);
        }

</style>