<style type="text/css">
    .img-shadow {
    box-shadow: 0 0 30px rgba(115, 128, 157, 0.3);
}

.img-hover {
    transition: all 0.2s ease-in;
    align-self: center;
}

.img-hover:hover {
    -webkit-transform: scale(1.1);
    -ms-transform: scale(1.1);
    transform: scale(1.1);
}

.uneven-box {
    margin-top: 100px;
}
 
 
</style>

<!DOCTYPE html>
 <html lang="en">
 <head>
      <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  </head>
 <body style="background-color:black;">

 
<div class="container mt-5">
    <div class="card" style="background-color:black;">
        <div class="row">
            <div class="col-md-4 img-hover">
            <img src="assets/h/s5.jpg" class="rounded img-shadow  img-fluid" alt="">   
            </div>
            <div class="col-md-8 img-hover" style="align-self: center;">
              <div class="card-body">
              <h2 class="card-title text-white">Services</h2>
              <p class="card-text text-white">
                         We provide transfers to and from all major airport in the UK.
             Also with our luxury
taxi service you can use
us for cruise transfers,
corporate travel,
business journeys, film sets, special days out such as Royal
Ascot, Soho farmhouse, Silverstone Circuit, trips to Oxford
University, London or other City tour &amp; special occasions.
Whether you are looking for Airport or long distance journey
we can mange with our excellent modern car and reliable
drivers. We want to create a positive first impression and
make all our passengers feel safe and secure when using our
taxi service.</p>
              </div> 
            </div>  
        </div> 
    </div>
</div>



<div class="container">
    <div class="card" style="background-color:black;">
        <div class="row">
            <div class="col-md-8 img-hover">
              <div class="card-body">
              <h2 class="card-title text-white">Meat and Greet</h2>
              <p class="card-text text-white">Your driver will be waiting for you holding a sign with your
name on at our meeting point in Airport when you arrive. We
use several flight monitoring systems and we will be aware if
your flight is delayed or due to arrive early. You can enjoy
your flight in the knowledge that we will be waiting for you at
the correct time of arrival.</p>
           
              </div> 
            </div>
             <div class="col-md-4 img-hover">
            <img src="assets/h/koo.jpeg" class=" img-fluid" alt="">   
            </div>  
        </div> 
    </div>
</div>



<div class="container">
    <div class="card" style="background-color:black;">
        <div class="row">
            <div class="col-md-4 img-hover">
            <img src="assets/h/price.jpeg" class="card-img" alt="">   
            </div>
            <div class="col-md-8 img-hover">
              <div class="card-body" >
              <h2 class="card-title text-white">Cost Effective</h2>
              <p class="card-text text-white">Our price is competitive fixed rate, so you can be assured of a
stress free journey all the time.</p>
              
              </div> 
            </div>  
        </div> 
    </div>
</div>

<div class="container">
    <div class="card" style="background-color:black;">
        <div class="row">
            <div class="col-md-8 img-hover">
              <div class="card-body">
              <h2 class="card-title text-white">Fast Response</h2>
              <p class="card-text text-white">Call us or request online quotation and requester and traveller
will receive email or text confirmation as quickly as possible.
[Email always within the hour.].</p>
              
              </div> 
            </div>
             <div class="col-md-4 img-hover">
            <img src="assets/h/loo.jpeg" class=" img-fluid" alt="">   
            </div>  
        </div> 
    </div>
</div>


<div class="container">
    <div class="card" style="background-color:black;">
        <div class="row">
            <div class="col-md-4 img-hover">
            <img src="assets/h/jon.jpeg" class="card-img" alt="">   
            </div>
            <div class="col-md-8 img-hover">
              <div class="card-body">
              <h2 class="card-title text-white">Availability</h2>
              <p class="card-text text-white">BUSINESS HOURS <br>

Open Everyday <br>
00:00 – 23:30 <br>
<br>
 
Call for free competitive quote during Business Hours or send your query online 24/7. For short notice Query or booking you can call On the number above business hours only.<br>
01865 749162</p>
              
              </div> 
            </div>  
        </div> 
    </div>
</div>


 
 
 </body>
 </html>





 