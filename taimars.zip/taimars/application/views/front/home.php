  
 <style type="text/css">
     *{
        font-family: montserrat;
     }

     .carousel-item{
        height: 100vh;
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
     }
     .carousel-caption{
        bottom: 220px;
     }
     .carousel-caption h5{
        font-size: 35px;
        text-transform: uppercase;
        letter-spacing: 2px;
        margin-top: 25px;
     }
     .carousel-caption p{
        width: 60%;
        margin: auto;
        font-size: 30px;
        line-height: 1.9;
     }
     .carousel-caption a{
        text-transform: uppercase;
        text-decoration: none;
        background: darkrange;
        padding: 10px 30px;
        display: inline-block;
        color: #000;
        margin-top: 15px;
     }

















@import url('https://fonts.googleapis.com/css2?family=PT+Sans&amp;display=swap');
.service_heading {
    text-transform: uppercase;
    position: relative;
}

.service_heading:after {
    content: '';
    position: absolute;
    top: 100%;
    left: 50%;
    transform: translateX(-50%);
    width: 0%;
    height: auto;
    border-bottom: 3px solid #3e4555;
    transition: all 0.3s linear;
}

.service_heading:hover:after {
    width: 20%
}

.service {
    color: #8d97ad;
    font-weight: 300;
}

.service h1, .service h2, .service h3, .service h4, .service h5, .service h6 {
    color: black;
}

.service h6 {
    line-height: 22px;
    font-size: 18px;
    color: #8d97ad;
}

.service .font-weight-medium {
    font-weight: 500;
    color: #3e4555;
}

.service .badge {
    line-height: 15px;
}

.service .badge-info {
    background: #188ef4;
}

.service .subtitle {
    color: #8d97ad;
    line-height: 24px;
}


.service .img-shadow {
    box-shadow: 0 0 30px rgba(115, 128, 157, 0.3);
     
}

.service .wrap-service .img-hover {
    transition: all 0.2s ease-in;
}

.service .wrap-service .img-hover:hover {
    -webkit-transform: scale(1.1);
    -ms-transform: scale(1.1);
    transform: scale(1.1);
}

.service .wrap-service .uneven-box {
    margin-top: 100px;
}

.service .btn-sm {
    padding: 6px 14px;
    font-size: 16px;
    background: #188ef4;
}

.service .btn-sm:hover {
    color: #188ef4;
    background: #fff;
    border: 1px solid #188ef4;
}





 






.img-shadow {
    box-shadow: 0 0 30px rgba(115, 128, 157, 0.3);
}

.img-hover {
    transition: all 0.2s ease-in;
    align-self: center;
}

.img-hover:hover {
    -webkit-transform: scale(1.1);
    -ms-transform: scale(1.1);
    transform: scale(1.1);
}

.uneven-box {
    margin-top: 100px;
}



  
*{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: poppins;
            text-decoration: none;
            list-style: none
        }
        .wrapper{
            display: -webkit-flex;
            display: -moz-flex;
            display: -ms-flex;
            display: -o-flex;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-image: url("assets/vs.jpg");
            -webkit-background-size: cover;
            background-size: cover;
            background-repeat: no-repeat;

            
        }
       
        #chkBox{
            display: none;
        }
        .mainContnt{
            width: 100%;
            height: 100%;
            display: -webkit-flex;
            display: -moz-flex;
            display: -ms-flex;
            display: -o-flex;
            display: flex;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.7s;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 300;
            background: rgba(0,0,0,0.8);
            
        }
        .box{
             
             
            width: 100%;
            height: 400px;
            
            transition: all 2s;
            margin: auto;
            
            
        }
        .bx1{
            background-image: url("assets/h/pon.jpeg");
            -webkit-background-size: cover;
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
        }
        .bx2{
            padding: 60px 32px 0 32px;
        }
        .bx2 h3 {
    margin-bottom: 16px;
    text-transform: uppercase;
}
        .login-form input {
    width: 100%;
    height: 52px;
    padding: 15px;
    margin-bottom: 25px;
}
        .login-form input[type="submit"] {
    background: deepskyblue;
    font-size: 25px;
    text-transform: uppercase;
    line-height: 20px;
    color: white;
}
        
        .close-box{
            position: relative;
            text-align: right;
            color: white;
            font-weight: bold;
            margin-top: 64px;
            margin-bottom: 32px;
            
            
        }
        .box-close {
    position: absolute;
    bottom: 350px;
    right: 5px;
}
        #chkBox:checked + .mainContnt{
            visibility: visible;
            opacity: 1;
        }
        #chkBox:checked + .mainContnt .box{
            transform: translateY(0);
        }


 </style>

 
 <!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css" integrity="sha512-doJrC/ocU8VGVRx3O9981+2aYUn3fuWVWvqLi1U+tA2MWVzsw+NVKq1PrENF03M+TYBP92PnYUlXFH1ZW0FpLw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

     <script
      type="text/javascript"
      src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"
    ></script>
    <script type="text/javascript">
      (function () {
        emailjs.init("wyz3rjtlYmwjjtDeM");
      })();
    </script>
    <style>
      .table{
        
        border-style: solid;
        width: 50%; 
        margin: auto;
      }  
      
    </style>
  </head>
  <body style="background-color: black;">

    <div class="container max-height d-flex align-items-center">

<div id="carouselExampleCaptions" class="carousel slide" data-bs-interval="3500" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active ">
        <img src="assets/h/s1.png" class="d-block w-100" alt="Sailboat 1">
       
      <div class="carousel-caption">
        <h5 class="animated bounceInRight" style="animation-delay: 1s">Enjoy A luxury and affordable way to travel</h5>
 
       <button class="btn btn-light px-1 py-2 fs-2 mt-3" > <a href="<?php echo base_url().'contact';?>">GET A QUOTE  </a>
        </button>
      </div>
    </div>
    <div class="carousel-item ">
        <img src="assets/h/s2.jpg" class="d-block w-100" alt="Sailboat 1">
       
      <div class="carousel-caption">
        <h5 class="animated bounceInRight" style="animation-delay: 1s">Enjoy A luxury and affordable way to travel</h5>
         
         <button class="btn btn-light px-1 py-2 fs-2 mt-5"><a href="<?php echo base_url().'contact';?>">GET A QUOTE  </a></button>
      </div>
    </div>
    <div class="carousel-item ">
       <img src="assets/h/s9.jpg" class="d-block w-100" alt="Sailboat 1">
      <div class="carousel-caption">
        <h5 class="animated bounceInRight" style="animation-delay: 1s">Enjoy A luxury and affordable way to travel</h5>
       
         <button class="btn btn-light px-1 py-2 fs-2 mt-5"><a href="<?php echo base_url().'contact';?>">GET A QUOTE  </a></button>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</div>



<!-- about page -->
   <div class="service py-5">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-10 col-11 mx-auto">
            <div class="row">
              <!-- left side data -->
              <div class="col-md-6 mt-md-4 m-0 ">
                <span class="badge-light badge rounded-pill px-1 py-2 my-2  ">
                 <h2 class="text-black">About</h2>
                </span>
                <h4></h4>
                <h4 class="text-white ">TaiMar cars is a family run taxi service based in Oxford. 
We provide luxury and affordable vehicles according  to
your needs. We have experienced, professional and  
friendly taxi drivers who will take you to your destination  
with care and safety.
<br>
<br>
Our customers are always our main priority and we love
to offer our customer best professional services. We pride
ourselves on providing a reliable, punctual and
confidential taxi service to our clients. 
<br>
<br> 
Our service includes airport transfers, cruise   transfers, corporate
travel, business journeys, film sets,   special days out such
as Bicester Village, Soho farmhouse,  Silverstone Circuit, trips
to Oxford University, London or  other City  other
special occasions. Our vehicles have  FREE WIFI upon
request for our clients to enjoy during their journey.</h4>
                
              </div>


              <!-- right side data -->
               
              <div class="col-md-5 mt-md-5 m-0 img-container">
                <div class="row wrap-service uneven-box">
                  <!-- left side images -->
                          <div class="col-md-6">
                         <div class="row">
                         <div class="col-md-12 img-hover mb-4">
                        <img alt="ux" class="rounded img-shadow img-fluid" src="assets/h/s4.jpg" />
                        </div>
                       
                        </div>
                       </div>
                  <!-- right side images -->
                       <div class="col-md-6 uneven-box">
                       <div class="row">
                       <div class="col-md-12 img-hover mb-4">
                        <img alt="ux" class="rounded img-shadow img-fluid" src="assets/h/hiii.jpeg" />
                       </div>
                       
                       </div>
                       </div>
                    </div>
                  </div>
            </div>
          </div>
        </div>
      </div>
    </div>


<!-- service page -->


 
<div class="container mt-5">
    <div class="text-center mb-5">  
            <h1 class="text-capitalize font-weight-blod" style="color:white;">Services
            </h1>
        </div>
    <div class="card" style="background-color:black;">
        <div class="row">
            <div class="col-md-4 img-hover">
            <img src="assets/h/s5.jpg" class="rounded img-shadow  img-fluid" alt="">   
            </div>
            <div class="col-md-8 img-hover" style="align-self: center;">
              <div class="card-body">
              <h2 class="card-title text-white">Services</h2>
              <p class="card-text text-white">
                         We provide transfers to and from all major airport in the UK.
             Also with our luxury
taxi service you can use
us for cruise transfers,
corporate travel,
business journeys, film sets, special days out such as Royal
Ascot, Soho farmhouse, Silverstone Circuit, trips to Oxford
University, London or other City tour &amp; special occasions.
Whether you are looking for Airport or long distance journey
we can mange with our excellent modern car and reliable
drivers. We want to create a positive first impression and
make all our passengers feel safe and secure when using our
taxi service.</p>
              </div> 
            </div>  
        </div> 
    </div>
</div>



<div class="container">
    <div class="card" style="background-color:black;">
        <div class="row">
            <div class="col-md-8 img-hover">
              <div class="card-body">
              <h2 class="card-title text-white">Meat and Greet</h2>
              <p class="card-text text-white">Your driver will be waiting for you holding a sign with your
name on at our meeting point in Airport when you arrive. We
use several flight monitoring systems and we will be aware if
your flight is delayed or due to arrive early. You can enjoy
your flight in the knowledge that we will be waiting for you at
the correct time of arrival.</p>
           
              </div> 
            </div>
             <div class="col-md-4 img-hover">
            <img src="assets/h/koo.jpeg" class=" img-fluid" alt="">   
            </div>  
        </div> 
    </div>
</div>



<div class="container">
    <div class="card" style="background-color:black;">
        <div class="row">
            <div class="col-md-4 img-hover">
            <img src="assets/h/price.jpeg" class="card-img" alt="">   
            </div>
            <div class="col-md-8 img-hover">
              <div class="card-body" >
              <h2 class="card-title text-white">Cost Effective</h2>
              <p class="card-text text-white">Our price is competitive fixed rate, so you can be assured of a
stress free journey all the time.</p>
              
              </div> 
            </div>  
        </div> 
    </div>
</div>

<div class="container">
    <div class="card" style="background-color:black;">
        <div class="row">
            <div class="col-md-8 img-hover">
              <div class="card-body">
              <h2 class="card-title text-white">Fast Response</h2>
              <p class="card-text text-white">Call us or request online quotation and requester and traveller
will receive email or text confirmation as quickly as possible.
[Email always within the hour.].</p>
              
              </div> 
            </div>
             <div class="col-md-4 img-hover">
            <img src="assets/h/loo.jpeg" class=" img-fluid" alt="">   
            </div>  
        </div> 
    </div>
</div>


<div class="container">
    <div class="card" style="background-color:black;">
        <div class="row">
            <div class="col-md-4 img-hover">
            <img src="assets/h/jon.jpeg" class="card-img" alt="">   
            </div>
            <div class="col-md-8 img-hover">
              <div class="card-body">
              <h2 class="card-title text-white">Availability</h2>
              <p class="card-text text-white">BUSINESS HOURS <br>

Open Everyday <br>
00:00 – 23:30 <br>
<br>
 
Call for free competitive quote during Business Hours or send your query online 24/7. For short notice Query or booking you can call On the number above business hours only.<br>
01865 749162</p>
              
              </div> 
            </div>  
        </div> 
    </div>
</div>


<!-- airpor prices -->
 <section class="p-5" style="background-color:black;">
          <div class="text-center mt-5">  
            <h1 class="text-capitalize font-weight-blod" style="color:white;">Airport Prices
            </h1>
        </div>
        <div class="table-responsive">
            <table  class="table bg-white">
                <thead class="bg-dark text-white">
                    <tr>
                        <th>Airport</th>
                        <th>Standard Car</th>
                        <th>Excutive Car</th>
                        <th>8 Seater</th>
                         
                    </tr>
                </thead>
                <tbody class="bg-dark text-white">
                    <tr>
                        
                        <td data-title="First Name">Heathrow</td>
                        <td data-title="Last Name">£95</td>
                        <td data-title="Age">£110</td>
                        <td data-title="State">£180</td>
                       
                    </tr>
                    <tr>
                        <td data-title="First Name">Getwick</td>
                        <td data-title="Last Name">£140</td>
                        <td data-title="Age">£155</td>
                        <td data-title="State">£210</td>
                     
                    </tr>
                    <tr>
                        <td data-title="First Name">Luton</td>
                        <td data-title="Last Name">£115</td>
                        <td data-title="Age">£140</td>
                        <td data-title="State">£230</td>
                      
                    </tr>
                    <tr>
                        <td data-title="First Name">Stansted</td>
                        <td data-title="Last Name">£150</td>
                        <td data-title="Age">£170</td>
                        <td data-title="State">£255</td>
                     
                    </tr>
                    <tr>
                        <td data-title="First Name">London</td>
                        <td data-title="Last Name">£170</td>
                        <td data-title="Age">£190</td>
                        <td data-title="State">£280</td>
                   
                    </tr>
                    <tr>
                        <td data-title="First Name">Birminghom</td>
                        <td data-title="Last Name">£120</td>
                        <td data-title="Age">£145</td>
                        <td data-title="State">£200</td>
                   
                    </tr>
                    <tr>
                        <td data-title="First Name">Southsmpton</td>
                        <td data-title="Last Name">£145</td>
                        <td data-title="Age">£165</td>
                        <td data-title="State">£230</td>
                   
                    </tr>
                    <tr>
                        <td data-title="First Name">Bristol</td>
                        <td data-title="Last Name">£160</td>
                        <td data-title="Age">£190</td>
                        <td data-title="State">£210</td>
                   
                    </tr>
                    <tr>
                        <td data-title="First Name">Private</td>
                        <td data-title="Last Name">£130</td>
                        <td data-title="Age">£140</td>
                        <td data-title="State">£220</td>
                   
                    </tr>
                </tbody>
            </table>
        </div>
    </section>

 
 <!-- Guotaion page -->
  <div class="container">
    <div class="text-center mt-5">  
            <h1 class="text-capitalize font-weight-blod" style="color:white;">Get A Quotation
            </h1>
        </div>


      <div class="fun">
        <div class="row m-0">
            
         
          <div class="col-md-6 p-0 pt-4 m-auto">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <h5 for="name"> </h5>
                        <label   class="form-label">Name</label>
            <input type="text"class="form-control"id="name"required  />
                    </div>
                 </div>

                     <div class="col-md-6">
                    <div class="mb-3">
                        <h5 for="email"> </h5>
                        <label   class="form-label">Email</label>
            <input type="email"class="form-control"id="email"required  />
                    </div>
                 </div>

                 <div class="col-md-6">
                    <div class="mb-3">
                        <h5 for="number"> </h5>
                        <label   class="form-label">Phone Number</label>
            <input type="number"class="form-control"id="number"required  />
                    </div>
                 </div>

                  <div class="col-md-6">
                    <div class="mb-3">
                        <h5 for="point"> </h5>
                        <label  class="form-label">Pick Up Point</label>
            <input type="text"class="form-control"id="point"required  />
                    </div>
                 </div>
                  <div class="col-md-6">
                    <div class="mb-3">
                        <h5 for="destination"> </h5>
                        <label   class="form-label">Destination</label>
            <input type="text"class="form-control"id="destination"required  />
                    </div>
                 </div>


                  <div class="col-md-6">
                    <div class="mb-3">
                        <h5 for="date"> </h5>
                        <label   class="form-label">Date of Travel</label>
            <input type="number"class="form-control"id="date"required  />
                    </div>
                 </div>

                  <div class="col-md-12">
                    <div class="mb-3">
                        <h5 for="pass"> </h5>
                        <label   class="form-label">Number of passengers</label>
            <input type="number"class="form-control"id="pass"required  />
                    </div>
                 </div>



                <div class="col-md-12">
                    <div class="mb-3">
                        <h5 for="message"> </h5>
                        <label  class="form-label">Message</label>
                        <textarea class="form-control" id="message" rows="3" required  ></textarea>
          
                    </div>
                 </div>
                 <button class="btn btn-warning btn-lg btn-block mt-3" onclick="sendMail()">Submit</button>
            </div>
          </div>    
        </div>
      </div>
    </div>


<!--  Contact page -->



    <div class="wrapper">
        <div class="btn-area">
            <div class="box bg-dark">
                <div class="boxes bx2">
                 <h2 class="text-white">Get in touch</h2>
                

                <a href="tel:01865 749162"><i class="fa fa-phone"></i></a>
                    <p class="mt-4 ms-3 text-white">Phone : 01865 749162</p>

                    <a href="mailto:info.taimarcars.com"><i class="fas fa-envelope"></i></a>
                    <p class="mt-4 ms-3 text-white">Email : info@taimarcars.com</p>
                    <li class="btn-group" role="group" aria-label="Basic outlined example">
                        <a class="btn btn-outline-info text-white" href="<?php echo base_url().'contact';?>">For Quatation</a>
                    </li>
                
                
            </div>
                
            </div>
             
            
        </div>
    </div>
    
 


    <script>









        function sendMail() {
  var params = {
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    number: document.getElementById("number").value,
    point: document.getElementById("point").value,
    destination: document.getElementById("destination").value,
    date: document.getElementById("date").value,
    pass: document.getElementById("pass").value,
   

    message: document.getElementById("message").value,
  };

  const serviceID = "service_bg2t2dn";
  const templateID = "template_zkr3og5";

    emailjs.send(serviceID, templateID, params)
    .then(res=>{
        document.getElementById("name").value = "";
        document.getElementById("email").value = "";
        document.getElementById("number").value = "";
        document.getElementById("point").value = "";
        document.getElementById("destination").value = "";
        document.getElementById("date").value = "";
        document.getElementById("pass").value = "";
        document.getElementById("message").value = "";
        console.log(res);
        alert("Your message sent successfully!!")

    })
    .catch(err=>console.log(err));

}

    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
 
  </body>
</html>