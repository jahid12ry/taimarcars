<!doctype html>
<html lang="en">

<head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
      .table{
        
        border-style: solid;
        width: 50%; 
        margin: auto;
      }  
      
    </style>
</head>

<body>
    <section class="  p-5" style="background-color:black;">
        <h3 class="pb-2 text-center text-white">Airport Prices</h3>
        <div class="table-responsive">
            <table  class="table bg-white">
                <thead class="bg-dark text-white">
                    <tr>
                        <th>Airport</th>
                        <th>Standard Car</th>
                        <th>Excutive Car</th>
                        <th>8 Seater</th>
                         
                    </tr>
                </thead>
                <tbody class="bg-dark text-white">
                    <tr>
                        
                        <td data-title="First Name">Heathrow</td>
                        <td data-title="Last Name">£95</td>
                        <td data-title="Age">£110</td>
                        <td data-title="State">£180</td>
                       
                    </tr>
                    <tr>
                        <td data-title="First Name">Getwick</td>
                        <td data-title="Last Name">£140</td>
                        <td data-title="Age">£155</td>
                        <td data-title="State">£210</td>
                     
                    </tr>
                    <tr>
                        <td data-title="First Name">Luton</td>
                        <td data-title="Last Name">£115</td>
                        <td data-title="Age">£140</td>
                        <td data-title="State">£230</td>
                      
                    </tr>
                    <tr>
                        <td data-title="First Name">Stansted</td>
                        <td data-title="Last Name">£150</td>
                        <td data-title="Age">£170</td>
                        <td data-title="State">£255</td>
                     
                    </tr>
                    <tr>
                        <td data-title="First Name">London</td>
                        <td data-title="Last Name">£170</td>
                        <td data-title="Age">£190</td>
                        <td data-title="State">£280</td>
                   
                    </tr>
                    <tr>
                        <td data-title="First Name">Birminghom</td>
                        <td data-title="Last Name">£120</td>
                        <td data-title="Age">£145</td>
                        <td data-title="State">£200</td>
                   
                    </tr>
                    <tr>
                        <td data-title="First Name">Southsmpton</td>
                        <td data-title="Last Name">£145</td>
                        <td data-title="Age">£165</td>
                        <td data-title="State">£230</td>
                   
                    </tr>
                    <tr>
                        <td data-title="First Name">Bristol</td>
                        <td data-title="Last Name">£160</td>
                        <td data-title="Age">£190</td>
                        <td data-title="State">£210</td>
                   
                    </tr>
                    <tr>
                        <td data-title="First Name">Private</td>
                        <td data-title="Last Name">£130</td>
                        <td data-title="Age">£140</td>
                        <td data-title="State">£220</td>
                   
                    </tr>
                </tbody>
            </table>
        </div>
    </section>
</body>

</html>