<style type="text/css">
    .fun{
        background-color: black;
    }
    .row{
        margin-bottom: 50px;
    }

</style>

 
 
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <script
      type="text/javascript"
      src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"
    ></script>
    <script type="text/javascript">
      (function () {
        emailjs.init("wyz3rjtlYmwjjtDeM");
      })();
    </script>



  </head>
  <body>
 
 

 <div class="fun">
     <div class="container">
        <div class="text-center">  
            <h1 class="text-capitalize font-weight-blod" style="color:white;">Get Quotation
            </h1>
        </div>


      <div class="fun">
        <div class="row m-0">
            
         
          <div class="col-md-6 p-0 pt-4 m-auto">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <h5 for="name"> </h5>
                        <label   class="form-label">Name</label>
            <input type="text"class="form-control"id="name"required  />
                    </div>
                 </div>

                     <div class="col-md-6">
                    <div class="mb-3">
                        <h5 for="email"> </h5>
                        <label   class="form-label">Email</label>
            <input type="email"class="form-control"id="email"required  />
                    </div>
                 </div>

                 <div class="col-md-6">
                    <div class="mb-3">
                        <h5 for="number"> </h5>
                        <label   class="form-label">Phone Number</label>
            <input type="number"class="form-control"id="number"required  />
                    </div>
                 </div>

                  <div class="col-md-6">
                    <div class="mb-3">
                        <h5 for="point"> </h5>
                        <label  class="form-label">Pick Up Point</label>
            <input type="text"class="form-control"id="point"required  />
                    </div>
                 </div>
                  <div class="col-md-6">
                    <div class="mb-3">
                        <h5 for="destination"> </h5>
                        <label   class="form-label">Destination</label>
            <input type="text"class="form-control"id="destination"required  />
                    </div>
                 </div>


                  <div class="col-md-6">
                    <div class="mb-3">
                        <h5 for="date"> </h5>
                        <label   class="form-label">Date of Travel</label>
            <input type="number"class="form-control"id="date"required  />
                    </div>
                 </div>

                  <div class="col-md-12">
                    <div class="mb-3">
                        <h5 for="pass"> </h5>
                        <label   class="form-label">Number of passengers</label>
            <input type="number"class="form-control"id="pass"required  />
                    </div>
                 </div>



                <div class="col-md-12">
                    <div class="mb-3">
                        <h5 for="message"> </h5>
                        <label  class="form-label">Message</label>
                        <textarea class="form-control" id="message" rows="3" required  ></textarea>
          
                    </div>
                 </div>
                 <button class="btn btn-warning btn-lg btn-block mt-3" onclick="sendMail()">Submit</button>
            </div>
          </div>    
        </div>
      </div>
    </div>
    </div>


    <script>

        function sendMail() {
  var params = {
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    number: document.getElementById("number").value,
    point: document.getElementById("point").value,
    destination: document.getElementById("destination").value,
    date: document.getElementById("date").value,
    pass: document.getElementById("pass").value,
   

    message: document.getElementById("message").value,
  };

  const serviceID = "service_bg2t2dn";
  const templateID = "template_zkr3og5";

    emailjs.send(serviceID, templateID, params)
    .then(res=>{
        document.getElementById("name").value = "";
        document.getElementById("email").value = "";
        document.getElementById("number").value = "";
        document.getElementById("point").value = "";
        document.getElementById("destination").value = "";
        document.getElementById("date").value = "";
        document.getElementById("pass").value = "";
        document.getElementById("message").value = "";
        console.log(res);
        alert("Your message sent successfully!!")

    })
    .catch(err=>console.log(err));

}

    </script>

 
  </body>
</html>









