
<style type="text/css">
    .fan{
        background-color: black;
    }
</style>


<!DOCTYPE html>
<html>
<head>
    <title>Payment Gateway</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
<div class="fan">
     <div class="container">
        <div class="row">
          <div class="col-md-8">
         
                        <?php if($this->cart->total_items() > 0) { 
                    foreach($cartItems as $item) { ?>
                         
                        <?php } ?>
                        <?php } else { ?>
                        
                        <?php } ?>
                     
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
        <?php if($this->session->flashdata('success') != ""):?>
        <div class="col-md-4">
            <?php echo $this->session->flashdata('success');?>
            <?php endif ?>
            <?php $loggedUser = $this->session->userdata('user');?>
            <form action="<?php echo base_url().'checkout/checkout';?>" method="POST"
                class="form-container  shadow-container" style="width:80%">
                <h3 class="mt-3 text-center text-white ">Shipping Details</h3><hr>
                <div class="form-group">
                    <label class="text-white" for="address">Address</label>
                    <textarea name="address" type="text" style="height:70px;"
                        class="form-control
                    <?php echo (form_error('address') != "") ? 'is-invalid' : '';?>"><?php echo set_value('address', $user['address']);?></textarea>
                    <?php echo form_error('address'); ?>
                </div>
                <div class="col-md-6">
                            <label class="text-white" for="email">Email Address</label>
                            <input type="text"
                                class="bg-light form-control <?php echo (form_error('email') != "") ? 'is-invalid' : '';?>"
                                name="email" value="<?php echo set_value('email', $user['email'])?>">
                            <?php echo form_error('email'); ?>
                        </div>
                        <div class="col-md-6">
                            <label class="text-white" for="phone">Contact Number</label>
                            <input type="tel"
                                class="bg-light form-control <?php echo (form_error('phone') != "") ? 'is-invalid' : '';?>"
                                name="phone" value="<?php echo set_value('phone', $user['phone'])?>">
                            <?php echo form_error('phone'); ?>
                        </div>
                        <!--<?php  if($this->cart->total_items() > 0) { ?>
                           <?php echo '$'.$this->cart->total();?> 
                            <?php } ?>-->
                        <div class="col-md-6">
                            <label class="text-white" for="price">Total price</label>
                            <input type="number"
                                class="bg-light form-control <?php echo (form_error('price') != "") ? 'is-invalid' : '';?>"
                                name="price" value="<?php echo set_value('price', $item['subtotal'])?>">
                            <?php echo form_error('price'); ?>
                        </div>
                
                <div>
                    <a href="<?php echo base_url().'cart'; ?>" class="btn btn-warning"><i class="fas fa-angle-left"></i>
                        Back to cart</a>
                    <button type="submit" name="placeOrder" class="btn btn-success">Place Order <i
                            class="fas fa-angle-right"></i></button>
                </div>
                </from>
        </div>

 
    </div>
</div>
    
</div>


<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>