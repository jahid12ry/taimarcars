<?php
defined('BASEPATH') OR exit ('No direct script access allowed');

class Login extends CI_Controller {
 

    public function index() {

        $this->load->view('front/partials/header');
         $this->load->view('front/login');
        $this->load->view('front/partials/footer');
        
    }

    
}
