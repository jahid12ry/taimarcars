<?php
defined('BASEPATH') OR exit ('No direct script access allowed');

class payment_model extends CI_Model {
    
    public function create($formArray) {
        $this->db->insert('payment', $formArray);
    }

    public function getByUsername($card_holder) {
        $this->db->where('card_holder', $card_holder);
        $mainuser = $this->db->get('payment')->row_array();
        return $mainuser;
    }

    public function getUsers() {
        $result = $this->db->get('payment')->result_array();
        return $result;
    }

    public function getUser($id) {
        $this->db->where('card_nummber', $id);
        $user = $this->db->get('payment')->row_array();
        return $user;
    }

     

}
