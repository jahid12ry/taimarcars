<?php
defined('BASEPATH') OR exit ('No direct script access allowed');

class taimar_model extends CI_Model {
    
    public function create($formArray) {
        $this->db->insert('admin', $formArray);
    }

    public function getByUsername($username) {
        $this->db->where('username', $username);
        $mainuser = $this->db->get('admin')->row_array();
        return $mainuser;
    }

    public function getUsers() {
        $result = $this->db->get('admin')->result_array();
        return $result;
    }

    public function getUser($id) {
        $this->db->where('admin_id', $id);
        $user = $this->db->get('admin')->row_array();
        return $user;
    }

    public function update($id, $formArray) {
        $this->db->where('admin_id',$id);
        $this->db->update('admin', $formArray);
    }

    public function delete($id) {
        $this->db->where('admin_id',$id);
        $this->db->delete('admin');
    }

    public function countUser() {
        $query = $this->db->get('admin');
        return $query->num_rows();
    }

}
