<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['stripe_api_key']='sk_test_51LVbsELW7u8GeNw5Wta8HqN2a8jcnCGY2N3z912tq5XrZM8zV9nj9lNrUozfsLHqE86lYlw91BM4wNmYbkiOvUwN00yEGRLRlV';
$config['stripe_publishable_key']='pk_test_51LVbsELW7u8GeNw5aJx0dL3SirXKmxUarhAeW9OQwawhwUtY75xUIPYFnqtMPM9XAVCKx8EjftAOdcPdOfgQQLNX00EMEuffK1';
$config['stripe_currency']='usd';